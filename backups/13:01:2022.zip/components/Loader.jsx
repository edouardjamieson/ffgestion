export default function Loader() {
    return (
        <div className="loader">
            <img src="/images/loading.svg" alt="loading" />
        </div>
    )
}
